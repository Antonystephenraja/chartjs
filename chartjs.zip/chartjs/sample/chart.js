
function getRandomIntInclusive(min, max) {
    min = Math.ceil(min);
    max = Math.floor(max);
    return Math.floor(Math.random() * (max - min + 1)) + min;
  }
  
  var ctx_live = document.getElementById("mycanvas");
  var myChart = new Chart(ctx_live, {
    type: "bar",
    data: {
      labels: ["stephen","raja","arun","mathavan"],
      datasets: [
        {
          data: [100,89,78,90],
          borderWidth: 1,
          borderColor: "red",
        
          label: "liveCount"
        }
      ]
    },

  });
  